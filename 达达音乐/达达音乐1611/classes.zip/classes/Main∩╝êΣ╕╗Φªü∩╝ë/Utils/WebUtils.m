//
//  WebUtils.m
//  百度音乐
//
//  Created by tarena on 16/10/27.
//  Copyright © 2016年 tarena. All rights reserved.
//
#import "RootModel.h"
#import "AdModel.h"
#import "KTVSongModel.h"
 #import "BangDanModel.h"
#import "SongListItemModel.h"
 #import "WebUtils.h"
#define kRecommentPath @"http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.plaza.index&from=ios&version=5.8.3&cuid=9bf9dd79422f0daff3b71760c8b3ff4711d6c9fb&channel=appstore&operator=0"
#define kSongslistPath @"http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.diy.gedan&page_no=1&page_size=30&from=ios&from=ios&version=5.8.3&cuid=511e7b5ebe3cb83b66008608b586c12220e6b5aa&channel=appstore&operator=0"
#define kHotCategoryPath @"http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.billboard.billCategory&format=json&from=ios&kflag=2&from=ios&version=5.8.3&cuid=511e7b5ebe3cb83b66008608b586c12220e6b5aa&channel=appstore&operator=0"
#define kSongInfoPath @"http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.song.getInfos&ts=1475164135&songid=%@&nw=2&l2p=395.1&lpb=320000&ext=MP3&format=json&from=ios&usup=1&lebo=0&aac=0&ucf=4&vid=&res=1&e=FuQ105WnGRfnAYDe2H%%2FYvCkKi8tA3QhyC6fmlIiYJHY%%3D&channel=24fc6b080e10ed8522fbb16da65619eafdf1db28&cuid=appstore&from=ios&version=5.9.0"
#define kKTVImageURLPath @"http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.active.showList&from=ios&version=5.8.3&cuid=511e7b5ebe3cb83b66008608b586c12220e6b5aa&channel=appstore&operator=0"
#define kKTVSongsPath @"http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.learn.now&from=ios&from=ios&version=5.8.3&cuid=511e7b5ebe3cb83b66008608b586c12220e6b5aa&channel=appstore&operator=0"
@implementation WebUtils


+(void)requestSongListDataWithCompletion:(MyCallback)callback
{
    
 
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    [manager setResponseSerializer:[AFHTTPResponseSerializer serializer]];
    
    [manager GET:kSongslistPath parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        
        NSArray *contentArr = dic[@"content"];
        
        NSArray *songListItemModelArr = [SongListItemModel arrayOfModelsFromDictionaries:contentArr error:nil];
        
        callback(songListItemModelArr);
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"获取歌单列表信息失败%@",error);
        
    }];
    
    
    
    
}

+(void)requestHotCategoryDataWithCompletion:(MyCallback)callback
{
    
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    [manager setResponseSerializer:[AFHTTPResponseSerializer serializer]];
    
    [manager GET:kHotCategoryPath parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        
        NSArray *contentArr = dic[@"content"];
        
        NSArray *bangdanModelArr = [BangDanModel arrayOfModelsFromDictionaries:contentArr error:nil];
        
        callback(bangdanModelArr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"获取推荐列表信息失败%@",error);
        
    }];
    
}

+(void)requestKTVImageURLWithCompletion:(MyCallback)calllback{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager setResponseSerializer:[AFHTTPResponseSerializer serializer]];
  
    
    [manager GET:kKTVImageURLPath parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        
        
        NSArray *adModels = [AdModel arrayOfModelsFromDictionaries:dic[@"result"] error:nil];
        
        calllback(adModels);
        
        
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"获取推荐列表信息失败%@",error);
        
    }];
    
}
+(void)requestKTVSongsWithCompletion:(MyCallback)calllback{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager setResponseSerializer:[AFHTTPResponseSerializer serializer]];
    
    
    [manager GET:kKTVSongsPath parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        
        
        NSArray *arr = dic[@"result"][@"items"];
        NSArray *songs = [KTVSongModel arrayOfModelsFromDictionaries:arr error:nil];
        
        
        calllback(songs);
        
        
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"获取推荐列表信息失败%@",error);
        
    }];
    
}


+(void)requestRecomentedWithCompletion:(MyCallback)calllback{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager setResponseSerializer:[AFHTTPResponseSerializer serializer]];
    
    
    [manager GET:kRecommentPath parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        
        RootModel *rm = [[RootModel alloc]initWithDictionary:dic error:nil];
       
        
        
        calllback(rm);
        
        
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"获取推荐列表信息失败%@",error);
        
    }];
    
}



@end
