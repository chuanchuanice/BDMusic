//
//  EntryCell.m
//  达达音乐1611
//
//  Created by tarena on 2017/2/27.
//  Copyright © 2017年 tarena. All rights reserved.
//

#import "EntryCell.h"

@implementation EntryCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setEntry:(Entry_RSModel *)entry{
    _entry = entry;
    [self.imageView setImageWithURL:entry.icon];
    self.titleLabel.text = entry.title;
    
    
    
}

@end
