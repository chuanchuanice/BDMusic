//
//  ScenceRS_ActModel.h
//  达达音乐1611
//
//  Created by tarena on 2017/2/27.
//  Copyright © 2017年 tarena. All rights reserved.
//

#import "JSONModel.h"

@interface ScenceRS_ActModel : JSONModel
@property(nonatomic,strong)NSURL  *icon_ios;
@property(nonatomic,strong)NSString  *scene_name;
@end
