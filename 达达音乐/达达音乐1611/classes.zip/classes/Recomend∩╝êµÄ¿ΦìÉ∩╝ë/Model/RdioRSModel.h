//
//  RdioRSModel.h
//  达达音乐1611
//
//  Created by 刘梓轩 on 2017/2/26.
//  Copyright © 2017年 tarena. All rights reserved.
//

#import "JSONModel.h"

@interface RdioRSModel : JSONModel
@property(nonatomic,strong)NSURL  *pic;
@property(nonatomic,strong)NSString  *title;

@end
