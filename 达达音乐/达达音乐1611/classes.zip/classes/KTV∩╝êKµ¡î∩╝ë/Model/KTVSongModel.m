//
//  KTVSongModel.m
//  百度音乐
//
//  Created by tarena on 16/11/2.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "KTVSongModel.h"

@implementation KTVSongModel

@end
