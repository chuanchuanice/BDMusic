//
//  AdModel.h
//  达达音乐1611
//
//  Created by tarena on 2017/2/24.
//  Copyright © 2017年 tarena. All rights reserved.
//

#import "JSONModel.h"

@interface AdModel : JSONModel
@property(nonatomic, strong)NSURL *picture;
@end
